//Slide animation

let toSlide = document.querySelectorAll(".book,footer");


window.addEventListener("scroll", function () {
    for (let v of toSlide) {
        if (window.scrollY + window.innerHeight > (v.offsetTop)) {
            v.classList.add("animation");
            v.classList.remove("none");
        } else if (v.classList.contains("animation") || window.scrollY > (v.offsetTop)) {
            v.classList.add("none");
            v.classList.remove("animation");
        }
    }
});

//Window pop-up

let login_button = document.getElementById("login-button");
let signup_button = document.getElementById("signup-button");
let login = document.getElementById("login");
let signup = document.getElementById("signup");


login_button.addEventListener("click",
    function () {
        if (login.classList.contains("none")) {
            login.classList.remove("none");
            login.classList.add("authorithation");


            signup.classList.remove("authorithation");
            signup.classList.add("none");
        } else {
            login.classList.add("none");
            login.classList.remove("authorithation");
        }
    });


signup_button.addEventListener("click",
    function () {
        if (signup.classList.contains("none")) {
            signup.classList.remove("none");
            signup.classList.add("authorithation");


            login.classList.remove("authorithation");
            login.classList.add("none");
        } else {
            signup.classList.add("none");
            signup.classList.remove("authorithation");
        }
    });

//Validation
function validateRegistration() {
    let password = document.registration.password.value;

    var passw = new RegExp(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/); // 6 symbols at least 1 lowercase, 1 uppercase and 1 digit

    if (passw.test(password)) {
        return true;
    } else {
        alert("Password should contain 6 symbols at least 1 lowercase, 1 uppercase and 1 digit");
        return false;
    }


}