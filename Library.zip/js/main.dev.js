"use strict";

//Slide animation
var toSlide = document.querySelectorAll(".book,footer");
window.addEventListener("scroll", function () {
  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = toSlide[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var v = _step.value;

      if (window.scrollY + window.innerHeight > v.offsetTop) {
        v.classList.add("animation");
        v.classList.remove("none");
      } else if (v.classList.contains("animation") || window.scrollY > v.offsetTop) {
        v.classList.add("none");
        v.classList.remove("animation");
      }
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator["return"] != null) {
        _iterator["return"]();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }
}); //Window pop-up

var login_button = document.getElementById("login-button");
var signup_button = document.getElementById("signup-button");
var login = document.getElementById("login");
var signup = document.getElementById("signup");
login_button.addEventListener("click", function () {
  if (login.classList.contains("none")) {
    login.classList.remove("none");
    login.classList.add("authorithation");
    signup.classList.remove("authorithation");
    signup.classList.add("none");
  } else {
    login.classList.add("none");
    login.classList.remove("authorithation");
  }
});
signup_button.addEventListener("click", function () {
  if (signup.classList.contains("none")) {
    signup.classList.remove("none");
    signup.classList.add("authorithation");
    login.classList.remove("authorithation");
    login.classList.add("none");
  } else {
    signup.classList.add("none");
    signup.classList.remove("authorithation");
  }
}); //Validation

function validateRegistration() {
  var password = document.registration.password.value;
  var passw = new RegExp(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/); // 6 symbols at least 1 lowercase, 1 uppercase and 1 digit

  if (passw.test(password)) {
    return true;
  } else {
    alert("Password should contain 6 symbols at least 1 lowercase, 1 uppercase and 1 digit");
    return false;
  }
}